import React, { useState } from 'react';

interface NavbarProps {
  onNavigate: (page: string) => void;
  activePage: string;
  isLoggedIn: boolean;
  userEmail?: string;
  isDarkMode: boolean;
  onToggleTheme: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ onNavigate, activePage, isLoggedIn, userEmail, isDarkMode, onToggleTheme }) => {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { id: 'home', label: 'DASHBOARD' },
    { id: 'artists', label: 'ROSTER' },
    { id: 'music', label: 'THE VAULT' },
    { id: 'streams', label: 'STREAMS' },
    { id: 'distribution', label: 'DISTRIBUTION' },
    { id: 'studio', label: 'STUDIO' },
    { id: 'store', label: 'STORE' },
    { id: 'gallery', label: 'GALLERY' },
    { id: 'demo', label: 'RECRUITMENT' },
  ];

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 border-b border-[#D4AF37]/20 ${isDarkMode ? 'bg-black/90 backdrop-blur-xl' : 'bg-white/80 backdrop-blur-md shadow-sm'}`}>
      <div className="max-w-[1600px] mx-auto px-6 md:px-12 flex justify-between items-center h-24">
        <div 
          className="flex items-center cursor-pointer group"
          onClick={() => onNavigate('home')}
        >
          <img 
            src="https://i.ibb.co/Pz6N9X3/century-logo.png" 
            alt="CENTURY MUSIC EMPIRE Logo" 
            className="w-16 h-16 mr-4 group-hover:scale-110 transition-transform drop-shadow-[0_0_10px_rgba(212,175,55,0.2)] object-contain"
            onError={(e) => {
              e.currentTarget.style.display = 'none';
              e.currentTarget.parentElement?.querySelector('.fallback-logo')?.classList.remove('hidden');
            }}
          />
          <div className="fallback-logo hidden w-12 h-12 bg-[#D4AF37] flex items-center justify-center mr-5 group-hover:scale-110 transition-transform shadow-[0_0_20px_rgba(212,175,55,0.1)]">
             <span className="text-black font-black text-2xl italic">C</span>
          </div>
          <div className="flex flex-col">
            <span className="text-2xl font-black tracking-tighter uppercase leading-none italic hidden sm:inline text-[#D4AF37]">CENTURY MUSIC EMPIRE</span>
            <span className="text-2xl font-black tracking-tighter uppercase leading-none italic sm:hidden text-[#D4AF37]">CME</span>
            <span className={`text-[8px] font-black uppercase tracking-[0.8em] ${isDarkMode ? 'text-[#D4AF37]/50' : 'text-zinc-400'} mt-1 hidden md:block`}>GLOBAL SONIC AUTHORITY</span>
          </div>
        </div>

        {/* Desktop Menu */}
        <div className="hidden lg:flex items-center space-x-2">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => onNavigate(link.id)}
              className={`px-3 py-2 text-[9px] font-black uppercase tracking-[0.3em] transition-all border-b-2 ${
                activePage === link.id ? 'text-[#D4AF37] border-[#D4AF37]' : `${isDarkMode ? 'text-[#D4AF37]/40' : 'text-zinc-400'} border-transparent hover:text-[#D4AF37] hover:border-[#D4AF37]/20`
              }`}
            >
              {link.label}
            </button>
          ))}
          
          <div className="h-8 w-px bg-[#D4AF37]/20 mx-4" />
          
          {/* Theme Toggle */}
          <button 
            onClick={onToggleTheme}
            className={`p-3 rounded-full transition-all group hover:scale-110 shadow-lg ${isDarkMode ? 'bg-zinc-900 text-[#D4AF37]' : 'bg-zinc-100 text-zinc-600'}`}
            title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          >
            {isDarkMode ? (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707m12.728 0l-.707-.707M6.343 6.343l-.707-.707M12 5a7 7 0 100 14 7 7 0 000-14z"/></svg>
            ) : (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            )}
          </button>

          <div className="h-8 w-px bg-[#D4AF37]/20 mx-4" />
          
          <button 
            onClick={() => onNavigate('login')}
            className={`px-8 py-3 text-[10px] font-black uppercase tracking-widest transition-all shadow-xl ${
              isLoggedIn 
              ? `${isDarkMode ? 'bg-zinc-900 border-[#D4AF37]/20' : 'bg-white border-zinc-200'} border text-[#D4AF37]` 
              : 'bg-[#D4AF37] text-black hover:bg-[#D4AF37]/80'
            }`}
          >
            {isLoggedIn ? 'IDENTITY' : 'AUTHENTICATE'}
          </button>
        </div>

        {/* Mobile Menu Button */}
        <div className="lg:hidden flex items-center space-x-4">
          <button 
            onClick={onToggleTheme}
            className={`p-3 rounded-full transition-all ${isDarkMode ? 'bg-zinc-900 text-[#D4AF37]' : 'bg-zinc-100 text-zinc-600'}`}
          >
            {isDarkMode ? (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707m12.728 0l-.707-.707M6.343 6.343l-.707-.707M12 5a7 7 0 100 14 7 7 0 000-14z"/></svg>
            ) : (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            )}
          </button>
          <button 
            className="p-4 text-[#D4AF37]"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? (
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            ) : (
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {isOpen && (
        <div className={`lg:hidden fixed inset-0 top-24 z-[100] p-10 flex flex-col space-y-8 animate-in slide-in-from-top-4 overflow-y-auto ${isDarkMode ? 'bg-black/95 backdrop-blur-2xl' : 'bg-white/95 backdrop-blur-xl shadow-2xl'}`}>
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => {
                onNavigate(link.id);
                setIsOpen(false);
              }}
              className={`text-left text-4xl font-black uppercase italic tracking-tighter ${
                activePage === link.id ? 'text-[#D4AF37]' : isDarkMode ? 'text-[#D4AF37]/20' : 'text-zinc-200'
              }`}
            >
              {link.label}
            </button>
          ))}
          <button 
            onClick={() => {
              onNavigate('login');
              setIsOpen(false);
            }}
            className="w-full py-6 text-center text-xl font-black uppercase bg-[#D4AF37] text-black mt-auto shadow-2xl"
          >
            {isLoggedIn ? 'IDENTITY FILE' : 'AUTHENTICATE'}
          </button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;