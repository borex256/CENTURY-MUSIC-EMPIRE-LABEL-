
import React from 'react';

interface FooterProps {
  onNavigate: (page: string) => void;
  isDarkMode: boolean;
}

const Footer: React.FC<FooterProps> = ({ onNavigate, isDarkMode }) => {
  const socials = [
    { 
      name: 'Instagram', 
      url: 'https://instagram.com/centurymusic', 
      handle: '@centurymusic',
      color: 'hover:bg-gradient-to-tr hover:from-[#f09433] hover:via-[#dc2743] hover:to-[#bc1888]' 
    },
    { 
      name: 'Twitter', 
      url: 'https://twitter.com/centurymusic', 
      handle: '@centurymusic',
      color: 'hover:bg-[#1DA1F2]' 
    },
    { 
      name: 'Facebook', 
      url: 'https://facebook.com/centurymusic', 
      handle: 'Century Music Empire',
      color: 'hover:bg-[#4267B2]' 
    },
    { 
      name: 'Spotify', 
      url: 'https://spotify.com', 
      handle: 'Century Empire',
      color: 'hover:bg-[#1DB954]' 
    },
    { 
      name: 'YouTube', 
      url: 'https://youtube.com', 
      handle: 'Century Music TV',
      color: 'hover:bg-[#FF0000]' 
    }
  ];

  const borderClass = isDarkMode ? 'border-white/10' : 'border-zinc-200';
  const subTextColor = isDarkMode ? 'text-zinc-400' : 'text-zinc-600';
  const subTitleColor = isDarkMode ? 'text-[#D4AF37]/40' : 'text-zinc-500';

  return (
    <footer className={`${isDarkMode ? 'bg-zinc-950' : 'bg-white shadow-2xl'} border-t ${borderClass} pt-24 pb-16 px-4 md:px-8 transition-colors duration-500`}>
      <div className="max-w-7xl mx-auto">
        
        {/* Terminal Location Map Section (Always Visible) */}
        <div className="mb-24 space-y-8">
           <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
              <div>
                <h4 className="text-[#D4AF37] font-black uppercase tracking-[0.4em] text-xs mb-2">Sound Box Records</h4>
                <h3 className="text-3xl font-black italic uppercase text-[#D4AF37] glow-text leading-none">IMPERIAL TERMINAL MAP</h3>
              </div>
              <div className="text-left md:text-right">
                <span className={`${subTitleColor} font-black uppercase text-[10px] tracking-widest block`}>Konge Poster Road, Kampala</span>
                <span className={`${subTitleColor} font-black uppercase text-[10px] tracking-widest block`}>Dispatch: +256 702 838 224</span>
              </div>
           </div>
           <div className={`aspect-[21/9] w-full border ${isDarkMode ? 'border-[#D4AF37]/10 grayscale invert opacity-30 hover:grayscale-0 hover:invert-0' : 'border-[#D4AF37]/40 grayscale opacity-40 hover:grayscale-0 hover:opacity-100'} hover:opacity-100 transition-all duration-[2s] overflow-hidden shadow-2xl`}>
              <iframe 
               src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15959.030573934444!2d32.58252!3d0.313611!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x177dbc0917032743%3A0xf63908f58359b360!2sKampala%2C%20Uganda!5e0!3m2!1sen!2sus!4v1716500000000!5m2!1sen!2sus" 
               width="100%" height="100%" loading="lazy" className="border-0 h-full w-full"
              ></iframe>
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="md:col-span-2">
            <div className="flex items-center mb-6 cursor-pointer" onClick={() => onNavigate('home')}>
              <img 
                src="https://i.ibb.co/Pz6N9X3/century-logo.png" 
                alt="Logo" 
                className="w-12 h-12 mr-3 object-contain drop-shadow-lg"
              />
              <span className="text-xl font-black tracking-tighter uppercase text-[#D4AF37] italic glow-text">Century Music Empire</span>
            </div>
            <p className={`${subTextColor} max-w-sm mb-6 leading-relaxed`}>
              Empowering artists and defining global sounds. Century Music Empire stands at the intersection of cultural heritage and futuristic innovation.
            </p>
          </div>
          <div>
            <h4 className="text-[#D4AF37] font-bold uppercase tracking-widest mb-6 text-xs">The Empire</h4>
            <ul className={`space-y-4 ${subTextColor} text-sm`}>
              <li><button onClick={() => onNavigate('home')} className="hover:text-[#D4AF37] transition-colors uppercase tracking-widest text-[10px] font-bold">Vision</button></li>
              <li><button onClick={() => onNavigate('artists')} className="hover:text-[#D4AF37] transition-colors uppercase tracking-widest text-[10px] font-bold">Leadership</button></li>
              <li><button onClick={() => onNavigate('music')} className="hover:text-[#D4AF37] transition-colors uppercase tracking-widest text-[10px] font-bold">Catalogue</button></li>
              <li><button onClick={() => onNavigate('demo')} className="hover:text-[#D4AF37] transition-colors uppercase tracking-widest text-[10px] font-bold">Contact</button></li>
            </ul>
          </div>
          <div>
            <h4 className="text-[#D4AF37] font-bold uppercase tracking-widest mb-6 text-xs">Operations</h4>
            <ul className={`space-y-4 ${subTextColor} text-sm`}>
              <li><button onClick={() => onNavigate('distribution')} className="hover:text-[#D4AF37] transition-colors uppercase tracking-widest text-[10px] font-bold">Online Hub</button></li>
              <li><button onClick={() => onNavigate('artists')} className="hover:text-[#D4AF37] transition-colors uppercase tracking-widest text-[10px] font-bold">Artist Relations</button></li>
              <li><button onClick={() => onNavigate('demo')} className="hover:text-[#D4AF37] transition-colors uppercase tracking-widest text-[10px] font-bold">Submissions</button></li>
              <li><button onClick={() => onNavigate('studio')} className="hover:text-[#D4AF37] transition-colors uppercase tracking-widest text-[10px] font-bold">Studio</button></li>
            </ul>
          </div>
        </div>

        {/* Social Media Section */}
        <div className={`border-y ${borderClass} py-16 mb-12`}>
          <h4 className={`${isDarkMode ? 'text-[#D4AF37]/60' : 'text-[#D4AF37]'} font-black uppercase tracking-[0.4em] mb-12 text-center text-xs`}>Connect With The Empire</h4>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-12">
            {socials.map((social) => (
              <a 
                key={social.name} 
                href={social.url} 
                target="_blank" 
                rel="noopener noreferrer"
                className="group flex flex-col items-center text-center space-y-4"
              >
                <div className={`w-16 h-16 rounded-full border ${isDarkMode ? 'border-[#D4AF37]/10 bg-[#D4AF37]/5 shadow-[0_0_15px_rgba(212,175,55,0.05)]' : 'border-zinc-200 bg-white shadow-md'} flex items-center justify-center transition-all duration-500 group-hover:border-transparent group-hover:shadow-2xl group-hover:scale-110 ${social.color}`}>
                  <span className={`font-black text-lg italic ${isDarkMode ? 'text-white' : 'text-zinc-700'} group-hover:text-white drop-shadow-md`}>{social.name[0]}</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-[#D4AF37] font-black text-[10px] uppercase tracking-[0.2em] transition-colors">{social.name}</span>
                  <span className={`${isDarkMode ? 'text-zinc-500' : 'text-zinc-400'} text-[10px] font-mono mt-1 opacity-60 group-hover:opacity-100 transition-opacity`}>{social.handle}</span>
                </div>
              </a>
            ))}
          </div>
        </div>

        <div className={`flex flex-col md:flex-row justify-between items-center ${isDarkMode ? 'text-zinc-500' : 'text-zinc-400'} text-[10px]`}>
          <p className="mb-4 md:mb-0 uppercase tracking-widest font-black">© 2025 CENTURY MUSIC EMPIRE. Defined by sound.</p>
          <div className="flex space-x-8 uppercase tracking-[0.2em] font-black">
            <button className="hover:text-[#D4AF37] transition-colors">Legal</button>
            <button className="hover:text-[#D4AF37] transition-colors">Privacy</button>
            <button className="hover:text-[#D4AF37] transition-colors">Cookies</button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
