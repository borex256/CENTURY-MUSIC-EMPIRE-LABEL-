import React, { useState, useRef, useEffect } from 'react';
import { Track } from '../types';

interface MusicPlayerProps {
  currentTrack: Track | null;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onNext: () => void;
  onPrev: () => void;
  isDarkMode: boolean;
}

const MusicPlayer: React.FC<MusicPlayerProps> = ({ currentTrack, isPlaying, onTogglePlay, onNext, onPrev, isDarkMode }) => {
  const [progress, setProgress] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch(e => console.error("Playback failed", e));
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying, currentTrack]);

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      const p = (audioRef.current.currentTime / audioRef.current.duration) * 100;
      setProgress(p || 0);
    }
  };

  if (!currentTrack) return null;

  return (
    <div className={`fixed bottom-0 left-0 w-full z-50 transition-all duration-500 border-t border-[#D4AF37]/10 py-4 px-4 md:px-8 shadow-2xl ${isDarkMode ? 'bg-black/90 backdrop-blur-xl' : 'bg-white/95 backdrop-blur-md'}`}>
      <audio 
        ref={audioRef} 
        src={currentTrack.audioUrl} 
        onTimeUpdate={handleTimeUpdate}
        onEnded={onNext}
      />
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center w-1/4 md:w-1/3">
          <img src={currentTrack.coverUrl} alt={currentTrack.title} className={`w-10 h-10 md:w-12 md:h-12 rounded-sm object-cover mr-4 grayscale hover:grayscale-0 transition-all border ${isDarkMode ? 'border-[#D4AF37]/10' : 'border-zinc-200 shadow-sm'}`} />
          <div className="hidden sm:block">
            <h4 className="text-[#D4AF37] font-bold text-sm truncate uppercase tracking-tighter italic">{currentTrack.title}</h4>
            <p className={`${isDarkMode ? 'text-[#D4AF37]/40' : 'text-zinc-400'} text-[10px] font-black uppercase tracking-widest`}>{currentTrack.artistName}</p>
          </div>
        </div>

        <div className="flex flex-col items-center w-2/4 md:w-1/3">
          <div className="flex items-center space-x-6 md:space-x-8 mb-2">
            <button onClick={onPrev} className={`${isDarkMode ? 'text-[#D4AF37]/40' : 'text-zinc-300'} hover:text-[#D4AF37] transition-all transform active:scale-90`}>
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path d="M8.445 14.832A1 1 0 0010 14v-2.798l5.445 3.63A1 1 0 0017 14V6a1 1 0 00-1.555-.832L10 8.798V6a1 1 0 00-1.555-.832l-6 4a1 1 0 000 1.664l6 4z"/></svg>
            </button>
            <button 
              onClick={onTogglePlay}
              className="w-10 h-10 md:w-12 md:h-12 bg-[#D4AF37] text-black rounded-full flex items-center justify-center hover:scale-110 active:scale-95 transition-all shadow-xl"
            >
              {isPlaying ? (
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd"/></svg>
              ) : (
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd"/></svg>
              )}
            </button>
            <button onClick={onNext} className={`${isDarkMode ? 'text-[#D4AF37]/40' : 'text-zinc-300'} hover:text-[#D4AF37] transition-all transform active:scale-90`}>
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path d="M4.555 5.168A1 1 0 003 6v8a1 1 0 001.555.832L10 11.202V14a1 1 0 001.555.832l6-4a1 1 0 000-1.664l-6-4A1 1 0 0010 6v2.798l-5.445-3.63z"/></svg>
            </button>
          </div>
          <div className={`w-full max-w-xs md:max-w-md h-1 ${isDarkMode ? 'bg-zinc-800' : 'bg-zinc-200'} rounded-full overflow-hidden shadow-inner`}>
            <div 
              className="h-full bg-[#D4AF37] transition-all duration-100 shadow-[0_0_10px_#D4AF37]" 
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <div className="flex items-center justify-end w-1/4 md:w-1/3 space-x-4">
          <div className={`hidden md:flex items-center ${isDarkMode ? 'text-[#D4AF37]/40' : 'text-zinc-400'}`}>
             <span className="text-[10px] font-black uppercase tracking-tighter">{currentTrack.duration}</span>
          </div>
          <button className={`${isDarkMode ? 'text-[#D4AF37]/40 hover:text-[#D4AF37]' : 'text-zinc-300 hover:text-[#D4AF37]'} transition-colors`}>
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default MusicPlayer;