import { GoogleGenAI, Type } from "@google/genai";

export const generateArtistBlurb = async (artistName: string, genre: string) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Write a short, professional, and evocative 2-sentence marketing blurb for a new artist named "${artistName}" who plays "${genre}". Make it sound like it's from a top-tier music label.`,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Pushing the boundaries of sonic innovation.";
  }
};

export const getDemoFeedback = async (lyrics: string) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Act as a senior A&R executive. Provide short, encouraging feedback on these lyrics: "${lyrics}".`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            vibe: { type: Type.STRING },
            feedback: { type: Type.STRING },
            potential: { type: Type.NUMBER }
          }
        }
      }
    });
    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Gemini Error:", error);
    return null;
  }
};